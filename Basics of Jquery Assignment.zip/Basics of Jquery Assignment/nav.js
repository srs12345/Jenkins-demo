$(document).ready(()=>{
	$(".item ul").hide();
	$(".my-image").click(function(){
		$(".item ul").slideToggle();
	})
})